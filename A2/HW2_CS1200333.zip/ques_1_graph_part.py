import matplotlib.pyplot as plt
values_of_support=[5,10,25,50,95]
file_names=["fsg","gSpan","gaston"]
fsg=[]
gSpan=[]
gaston=[]
for k in file_names:
    for i in values_of_support:
        if k=="fsg":
            out_file_name=k+"_"+str(i)+".txt"
            obj_file=open(out_file_name,'r')
            for sentence in obj_file:
                if "Elapsed" in sentence and "Time" in sentence:
                    words=sentence.split(" ")
                    last_word=words[-1]
                    elapse_time=float(last_word[:-6])
                    fsg.append(elapse_time)

            obj_file.close()
        elif k=="gSpan":
            out_file_name=k+"_"+str(i)+".txt"
            obj_file=open(out_file_name,'r')
            for sentence in obj_file:
                if "sec" in sentence:
                    words=sentence.split(" ")
                    last_word=words[-1]
                    elapse_time=float(last_word[3:-4])
                    gSpan.append(elapse_time)

            obj_file.close()
        elif k=="gaston":
            out_file_name=k+"_"+str(i)+".txt"
            obj_file=open(out_file_name,'r')
            for sentence in obj_file:
                if "Approximate" in sentence and "runtime" in sentence:
                    words=sentence.split(" ")
                    last_word=words[-1]
                    elapse_time=float(last_word[:-2])
                    gaston.append(elapse_time)

            obj_file.close()
plt.figure(figsize=(10, 6))  
plt.plot(values_of_support, fsg, marker='o', label='FSG', color='red')
plt.plot(values_of_support, gSpan, marker='s', label='gSpan', color='blue')
plt.plot(values_of_support, gaston, marker='^', label='Gaston', color='green')
plt.xlabel('Support Percentage')
plt.ylabel('Time (seconds)')
plt.title('Algorithm Execution Time vs. Support Percentage')
plt.legend()
plt.grid(True)
plt.savefig('CS1200333_question1.png')