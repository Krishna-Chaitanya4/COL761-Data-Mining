#!/bin/bash
Given_file="$1"
Given_dim="$2"
graph_file_ouput="$3"
module load apps/anaconda/3
python - <<END
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
Given_points = np.loadtxt("$Given_file")
Num_of_clusters = []
variation_factor = []
for i in range(1, 16): 
    clustering_object = KMeans(n_clusters=i, random_state=0, n_init=10)
    clustering_object.fit(Given_points)
    variation_obj = clustering_object.inertia_
    Num_of_clusters.append(i)
    variation_factor.append(variation_obj)
plt.figure(figsize=(8, 4))
plt.plot(Num_of_clusters, variation_factor, marker='o', linestyle='-', color='b')
plt.title('Elbow Plot for K-Means Clustering (Dimension $Given_dim)')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Inertia')
plt.grid(True)
plt.savefig("$graph_file_ouput")
END

