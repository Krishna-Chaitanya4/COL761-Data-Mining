#!/bin/bash
python ques_1_input_part.py $1
rm -rf fsg_*
./fsg -s 95.0 -pt  fsginput.dat >> fsg_95.txt
./fsg -s 50.0 -pt  fsginput.dat >> fsg_50.txt
./fsg -s 25.0 -pt  fsginput.dat >> fsg_25.txt
./fsg -s 10.0 -pt  fsginput.dat >> fsg_10.txt
./fsg -s 5.0 -pt  fsginput.dat >> fsg_5.txt
rm -rf gSpan_*
./gSpan-64 -f gspaninput.dat -s 0.95 >> gSpan_95.txt
./gSpan-64 -f gspaninput.dat -s 0.5 >> gSpan_50.txt
./gSpan-64 -f gspaninput.dat -s 0.25 >> gSpan_25.txt
./gSpan-64 -f gspaninput.dat -s 0.1 >> gSpan_10.txt
./gSpan-64 -f gspaninput.dat -s 0.05 >> gSpan_5.txt
module load compiler/gcc/11.2.0
rm -rf gaston_*
./gaston 60905 gastoninput.dat  >> gaston_95.txt
./gaston 32055 gastoninput.dat  >> gaston_50.txt
./gaston 16028 gastoninput.dat  >> gaston_25.txt
./gaston 6411 gastoninput.dat  >> gaston_10.txt
./gaston 3206 gastoninput.dat  >> gaston_5.txt
module load apps/anaconda/3
python ques_1_graph_part.py
