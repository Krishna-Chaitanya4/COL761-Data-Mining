-----------(i) explains all the files you have bundled

--for the quetion-1 we added the following files

we add the compiled version of the fsg,gaston ,gSpan-64 we also added the given input dataset(167.txt_graph)
ques_1_input_part.py this file converts given input file to three different formats for the three algos
ques_1_graph_part.py this file extracts the running times and plot the graph
question1.sh this file is script file which loads the modules and run all the above python files to generate the ouput graph

--for the question-2 we added the following files 

we added the datasets CS1200333_generated_dataset_4D.dat ,CS1200333_generated_dataset_5D.dat  ,CS1200333_generated_dataset_6D.dat  ,CS1200333_generated_dataset_7D.dat
we also added the script file to generate the elbow_plot elbow_plot.sh
we also added the output_graphs 4.png,5.png,6.png,7.png for respective dimensional datasets

we also added report file

------------(ii) has entry numbers and names of all team members

Banoth Chethan Naik            - 2020CS10333
Perugu Krishna Chaitanya Yadav - 2020EE10521
Devarakonda Ronith Kumar       - 2020EE10486


------------(iii) has instructions on how to execute your code

--for question-1 run the following command

bash question1.sh <input> (for example to the given dataset 167.txt_graph we used  :- bash question1.sh 167.txt_graph)

but we wrote the absolute values for the gaston in running in the question.sh (we need to change manually for ./gaston 63110 <file> here 63110 is absolute wher we need to change according to the given input file)

--for question-2 run the following command

sh elbow_plot.sh <dataset> <dimension> q3_<dimension>_<RollNo>.png

As given in the question paper


------------(iv) contribution in percentage of each student.

All three members of the team contributed equally 

Banoth Chethan Naik            - 2020CS10333 ---33.33%
Perugu Krishna Chaitanya Yadav - 2020EE10521 ---33.33%
Devarakonda Ronith Kumar       - 2020EE10486 ---33.33%


