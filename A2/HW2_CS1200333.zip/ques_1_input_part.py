import sys
input_file_name=sys.argv[1]
file=open(input_file_name,'r')
file1=open("fsginput.dat",'w')
file2=open("gspaninput.dat",'w')
file3=open("gastoninput.dat",'w')
bit=0
count=0
to=0
num=0
lnum=1
hash_mapping={}
hash_count=1
for line in file:
    if line=="\n":
        continue
    elif "#" in line:
        file1.write("t #\n")
        z="t # "+str(lnum)+"\n"
        file2.write(z)
        file3.write(z)
        lnum=lnum+1
        bit=0
        num=0
    elif bit==0:
        count=int(line.strip())
        bit=1
    elif count>0:
        if num==0:
            s="v "
            s=s+str(to)+" "
            if hash_mapping.get(line.strip()) is not None:
                s=s+str(hash_mapping[line.strip()])+"\n"
            else :
                hash_mapping[line.strip()]=hash_count
                hash_count=hash_count+1
                s=s+str(hash_mapping[line.strip()])+"\n"

            file1.write(s)
            file2.write(s)
            file3.write(s)
            to=to+1
            count=count-1
        else :
            s="u "
            s=s+line.strip()+"\n"
            s1="e "
            s1=s1+line.strip()+"\n"
            file1.write(s)
            file2.write(s1)
            file3.write(s1)
            count=count-1

    else:
       count=int(line.strip())
       to=0 
       num=1
file.close()
file1.close()
file2.close()
file3.close()